Simple JPA Hibernate Standalone with dbUnit tests
=================================================

This is a very simple project using hibernate as a standalone (no server required) JPA provider.
Features simple tests with dbUnit.

See my blog : http://geowarin.wordpress.com/2013/01/20/using-hibernate-as-a-jpa-provider-in-a-java-se-environment-and-run-tests-with-dbunit/