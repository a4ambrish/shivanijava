Spring Data JPA standalone - dbUnit tests
=========================================

This project demonstrate how to use Spring Data JPA in a Java SE environment and how to test our repositories with dbUnit.

See my blog for further information : http://geowarin.wordpress.com/2013/01/21/using-spring-data-jpa-in-a-java-se-environment-and-run-tests-with-dbunit
