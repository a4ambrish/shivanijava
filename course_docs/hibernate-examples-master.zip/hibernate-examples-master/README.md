Hibernate examples
==================

Hibernate examples from my blog http://geowarin.wordpress.com/tag/hibernate