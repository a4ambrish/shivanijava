Generate DDL with hibernate configuration
=========================================

A little trick to generate DDL using hibernate.

See my blog : http://geowarin.wordpress.com/2013/01/21/generate-ddl-with-hibernate